// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:srv/SetJointStiffness.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__SRV__SET_JOINT_STIFFNESS_H_
#define FRANKA_MSGS__SRV__SET_JOINT_STIFFNESS_H_

#include "franka_msgs/srv/detail/set_joint_stiffness__struct.h"
#include "franka_msgs/srv/detail/set_joint_stiffness__functions.h"
#include "franka_msgs/srv/detail/set_joint_stiffness__type_support.h"

#endif  // FRANKA_MSGS__SRV__SET_JOINT_STIFFNESS_H_
