// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:srv/SetForceTorqueCollisionBehavior.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__SRV__SET_FORCE_TORQUE_COLLISION_BEHAVIOR_H_
#define FRANKA_MSGS__SRV__SET_FORCE_TORQUE_COLLISION_BEHAVIOR_H_

#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__struct.h"
#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__functions.h"
#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__type_support.h"

#endif  // FRANKA_MSGS__SRV__SET_FORCE_TORQUE_COLLISION_BEHAVIOR_H_
