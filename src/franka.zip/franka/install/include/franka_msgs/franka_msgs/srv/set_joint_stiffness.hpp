// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__SRV__SET_JOINT_STIFFNESS_HPP_
#define FRANKA_MSGS__SRV__SET_JOINT_STIFFNESS_HPP_

#include "franka_msgs/srv/detail/set_joint_stiffness__struct.hpp"
#include "franka_msgs/srv/detail/set_joint_stiffness__builder.hpp"
#include "franka_msgs/srv/detail/set_joint_stiffness__traits.hpp"
#include "franka_msgs/srv/detail/set_joint_stiffness__type_support.hpp"

#endif  // FRANKA_MSGS__SRV__SET_JOINT_STIFFNESS_HPP_
