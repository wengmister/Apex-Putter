// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from franka_msgs:srv/SetForceTorqueCollisionBehavior.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "franka_msgs/srv/set_force_torque_collision_behavior.hpp"


#ifndef FRANKA_MSGS__SRV__DETAIL__SET_FORCE_TORQUE_COLLISION_BEHAVIOR__STRUCT_HPP_
#define FRANKA_MSGS__SRV__DETAIL__SET_FORCE_TORQUE_COLLISION_BEHAVIOR__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Request __attribute__((deprecated))
#else
# define DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Request __declspec(deprecated)
#endif

namespace franka_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetForceTorqueCollisionBehavior_Request_
{
  using Type = SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>;

  explicit SetForceTorqueCollisionBehavior_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<double, 7>::iterator, double>(this->lower_torque_thresholds_nominal.begin(), this->lower_torque_thresholds_nominal.end(), 0.0);
      std::fill<typename std::array<double, 7>::iterator, double>(this->upper_torque_thresholds_nominal.begin(), this->upper_torque_thresholds_nominal.end(), 0.0);
      std::fill<typename std::array<double, 6>::iterator, double>(this->lower_force_thresholds_nominal.begin(), this->lower_force_thresholds_nominal.end(), 0.0);
      std::fill<typename std::array<double, 6>::iterator, double>(this->upper_force_thresholds_nominal.begin(), this->upper_force_thresholds_nominal.end(), 0.0);
    }
  }

  explicit SetForceTorqueCollisionBehavior_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : lower_torque_thresholds_nominal(_alloc),
    upper_torque_thresholds_nominal(_alloc),
    lower_force_thresholds_nominal(_alloc),
    upper_force_thresholds_nominal(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<double, 7>::iterator, double>(this->lower_torque_thresholds_nominal.begin(), this->lower_torque_thresholds_nominal.end(), 0.0);
      std::fill<typename std::array<double, 7>::iterator, double>(this->upper_torque_thresholds_nominal.begin(), this->upper_torque_thresholds_nominal.end(), 0.0);
      std::fill<typename std::array<double, 6>::iterator, double>(this->lower_force_thresholds_nominal.begin(), this->lower_force_thresholds_nominal.end(), 0.0);
      std::fill<typename std::array<double, 6>::iterator, double>(this->upper_force_thresholds_nominal.begin(), this->upper_force_thresholds_nominal.end(), 0.0);
    }
  }

  // field types and members
  using _lower_torque_thresholds_nominal_type =
    std::array<double, 7>;
  _lower_torque_thresholds_nominal_type lower_torque_thresholds_nominal;
  using _upper_torque_thresholds_nominal_type =
    std::array<double, 7>;
  _upper_torque_thresholds_nominal_type upper_torque_thresholds_nominal;
  using _lower_force_thresholds_nominal_type =
    std::array<double, 6>;
  _lower_force_thresholds_nominal_type lower_force_thresholds_nominal;
  using _upper_force_thresholds_nominal_type =
    std::array<double, 6>;
  _upper_force_thresholds_nominal_type upper_force_thresholds_nominal;

  // setters for named parameter idiom
  Type & set__lower_torque_thresholds_nominal(
    const std::array<double, 7> & _arg)
  {
    this->lower_torque_thresholds_nominal = _arg;
    return *this;
  }
  Type & set__upper_torque_thresholds_nominal(
    const std::array<double, 7> & _arg)
  {
    this->upper_torque_thresholds_nominal = _arg;
    return *this;
  }
  Type & set__lower_force_thresholds_nominal(
    const std::array<double, 6> & _arg)
  {
    this->lower_force_thresholds_nominal = _arg;
    return *this;
  }
  Type & set__upper_force_thresholds_nominal(
    const std::array<double, 6> & _arg)
  {
    this->upper_force_thresholds_nominal = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Request
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Request
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetForceTorqueCollisionBehavior_Request_ & other) const
  {
    if (this->lower_torque_thresholds_nominal != other.lower_torque_thresholds_nominal) {
      return false;
    }
    if (this->upper_torque_thresholds_nominal != other.upper_torque_thresholds_nominal) {
      return false;
    }
    if (this->lower_force_thresholds_nominal != other.lower_force_thresholds_nominal) {
      return false;
    }
    if (this->upper_force_thresholds_nominal != other.upper_force_thresholds_nominal) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetForceTorqueCollisionBehavior_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetForceTorqueCollisionBehavior_Request_

// alias to use template instance with default allocator
using SetForceTorqueCollisionBehavior_Request =
  franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace franka_msgs


#ifndef _WIN32
# define DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Response __attribute__((deprecated))
#else
# define DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Response __declspec(deprecated)
#endif

namespace franka_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetForceTorqueCollisionBehavior_Response_
{
  using Type = SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>;

  explicit SetForceTorqueCollisionBehavior_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->error = "";
    }
  }

  explicit SetForceTorqueCollisionBehavior_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : error(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->error = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _error_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _error_type error;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__error(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->error = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Response
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Response
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetForceTorqueCollisionBehavior_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->error != other.error) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetForceTorqueCollisionBehavior_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetForceTorqueCollisionBehavior_Response_

// alias to use template instance with default allocator
using SetForceTorqueCollisionBehavior_Response =
  franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace franka_msgs


// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Event __attribute__((deprecated))
#else
# define DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Event __declspec(deprecated)
#endif

namespace franka_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetForceTorqueCollisionBehavior_Event_
{
  using Type = SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>;

  explicit SetForceTorqueCollisionBehavior_Event_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_init)
  {
    (void)_init;
  }

  explicit SetForceTorqueCollisionBehavior_Event_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _info_type =
    service_msgs::msg::ServiceEventInfo_<ContainerAllocator>;
  _info_type info;
  using _request_type =
    rosidl_runtime_cpp::BoundedVector<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>>;
  _request_type request;
  using _response_type =
    rosidl_runtime_cpp::BoundedVector<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>>;
  _response_type response;

  // setters for named parameter idiom
  Type & set__info(
    const service_msgs::msg::ServiceEventInfo_<ContainerAllocator> & _arg)
  {
    this->info = _arg;
    return *this;
  }
  Type & set__request(
    const rosidl_runtime_cpp::BoundedVector<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<franka_msgs::srv::SetForceTorqueCollisionBehavior_Request_<ContainerAllocator>>> & _arg)
  {
    this->request = _arg;
    return *this;
  }
  Type & set__response(
    const rosidl_runtime_cpp::BoundedVector<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<franka_msgs::srv::SetForceTorqueCollisionBehavior_Response_<ContainerAllocator>>> & _arg)
  {
    this->response = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator> *;
  using ConstRawPtr =
    const franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Event
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__franka_msgs__srv__SetForceTorqueCollisionBehavior_Event
    std::shared_ptr<franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetForceTorqueCollisionBehavior_Event_ & other) const
  {
    if (this->info != other.info) {
      return false;
    }
    if (this->request != other.request) {
      return false;
    }
    if (this->response != other.response) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetForceTorqueCollisionBehavior_Event_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetForceTorqueCollisionBehavior_Event_

// alias to use template instance with default allocator
using SetForceTorqueCollisionBehavior_Event =
  franka_msgs::srv::SetForceTorqueCollisionBehavior_Event_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace franka_msgs

namespace franka_msgs
{

namespace srv
{

struct SetForceTorqueCollisionBehavior
{
  using Request = franka_msgs::srv::SetForceTorqueCollisionBehavior_Request;
  using Response = franka_msgs::srv::SetForceTorqueCollisionBehavior_Response;
  using Event = franka_msgs::srv::SetForceTorqueCollisionBehavior_Event;
};

}  // namespace srv

}  // namespace franka_msgs

#endif  // FRANKA_MSGS__SRV__DETAIL__SET_FORCE_TORQUE_COLLISION_BEHAVIOR__STRUCT_HPP_
