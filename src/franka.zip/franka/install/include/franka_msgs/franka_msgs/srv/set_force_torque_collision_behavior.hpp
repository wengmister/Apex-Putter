// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__SRV__SET_FORCE_TORQUE_COLLISION_BEHAVIOR_HPP_
#define FRANKA_MSGS__SRV__SET_FORCE_TORQUE_COLLISION_BEHAVIOR_HPP_

#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__struct.hpp"
#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__builder.hpp"
#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__traits.hpp"
#include "franka_msgs/srv/detail/set_force_torque_collision_behavior__type_support.hpp"

#endif  // FRANKA_MSGS__SRV__SET_FORCE_TORQUE_COLLISION_BEHAVIOR_HPP_
