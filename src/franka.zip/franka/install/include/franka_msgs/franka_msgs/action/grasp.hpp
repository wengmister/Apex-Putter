// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__ACTION__GRASP_HPP_
#define FRANKA_MSGS__ACTION__GRASP_HPP_

#include "franka_msgs/action/detail/grasp__struct.hpp"
#include "franka_msgs/action/detail/grasp__builder.hpp"
#include "franka_msgs/action/detail/grasp__traits.hpp"
#include "franka_msgs/action/detail/grasp__type_support.hpp"

#endif  // FRANKA_MSGS__ACTION__GRASP_HPP_
