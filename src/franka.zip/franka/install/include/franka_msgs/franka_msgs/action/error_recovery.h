// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:action/ErrorRecovery.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__ACTION__ERROR_RECOVERY_H_
#define FRANKA_MSGS__ACTION__ERROR_RECOVERY_H_

#include "franka_msgs/action/detail/error_recovery__struct.h"
#include "franka_msgs/action/detail/error_recovery__functions.h"
#include "franka_msgs/action/detail/error_recovery__type_support.h"

#endif  // FRANKA_MSGS__ACTION__ERROR_RECOVERY_H_
