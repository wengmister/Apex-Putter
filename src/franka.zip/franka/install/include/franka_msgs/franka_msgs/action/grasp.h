// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:action/Grasp.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__ACTION__GRASP_H_
#define FRANKA_MSGS__ACTION__GRASP_H_

#include "franka_msgs/action/detail/grasp__struct.h"
#include "franka_msgs/action/detail/grasp__functions.h"
#include "franka_msgs/action/detail/grasp__type_support.h"

#endif  // FRANKA_MSGS__ACTION__GRASP_H_
