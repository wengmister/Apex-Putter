// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:action/Move.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__ACTION__MOVE_H_
#define FRANKA_MSGS__ACTION__MOVE_H_

#include "franka_msgs/action/detail/move__struct.h"
#include "franka_msgs/action/detail/move__functions.h"
#include "franka_msgs/action/detail/move__type_support.h"

#endif  // FRANKA_MSGS__ACTION__MOVE_H_
