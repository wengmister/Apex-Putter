// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__MSG__COLLISION_INDICATORS_HPP_
#define FRANKA_MSGS__MSG__COLLISION_INDICATORS_HPP_

#include "franka_msgs/msg/detail/collision_indicators__struct.hpp"
#include "franka_msgs/msg/detail/collision_indicators__builder.hpp"
#include "franka_msgs/msg/detail/collision_indicators__traits.hpp"
#include "franka_msgs/msg/detail/collision_indicators__type_support.hpp"

#endif  // FRANKA_MSGS__MSG__COLLISION_INDICATORS_HPP_
