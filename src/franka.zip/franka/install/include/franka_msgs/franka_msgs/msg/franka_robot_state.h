// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:msg/FrankaRobotState.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__MSG__FRANKA_ROBOT_STATE_H_
#define FRANKA_MSGS__MSG__FRANKA_ROBOT_STATE_H_

#include "franka_msgs/msg/detail/franka_robot_state__struct.h"
#include "franka_msgs/msg/detail/franka_robot_state__functions.h"
#include "franka_msgs/msg/detail/franka_robot_state__type_support.h"

#endif  // FRANKA_MSGS__MSG__FRANKA_ROBOT_STATE_H_
