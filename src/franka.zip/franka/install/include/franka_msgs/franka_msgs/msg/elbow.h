// generated from rosidl_generator_c/resource/idl.h.em
// with input from franka_msgs:msg/Elbow.idl
// generated code does not contain a copyright notice

#ifndef FRANKA_MSGS__MSG__ELBOW_H_
#define FRANKA_MSGS__MSG__ELBOW_H_

#include "franka_msgs/msg/detail/elbow__struct.h"
#include "franka_msgs/msg/detail/elbow__functions.h"
#include "franka_msgs/msg/detail/elbow__type_support.h"

#endif  // FRANKA_MSGS__MSG__ELBOW_H_
